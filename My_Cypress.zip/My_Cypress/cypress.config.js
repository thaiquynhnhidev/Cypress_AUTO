/*
const { defineConfig } = require("cypress");
//const allureWriter = require('@shelex/cypress-allure-plugin/writer');

module.exports = defineConfig({
  // setupNodeEvents can be defined in either
  // the e2e or component configuration
  e2e: {
    specPattern: "./cypress/VNCTest/**.*",
    //baseURL: "https://the-internet.herokuapp.com"
    //baseURL: "https://vinachain-swap.greensoftware.asia/"
    //baseURL: "https://swap.vinachain.io"
      
    },
    setupNodeEvents(on, config) {
    //allureWriter(on, config);
    //return config;
  }
});
*/

const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    specPattern: "./cypress/tests/*/*",
    //specPattern: "./cypress/VNCTest/**/*",
    //baseUrl: 'https://the-internet.herokuapp.com', // URL cơ sở cho các lệnh cy.visit()
    //baseUrl: 'https://www.amazon.com',
    baseUrl: 'https://www.demoblaze.com',
    //baseUrl: 'https://vinachain-swap.greensoftware.asia',
    supportFile: 'cypress/support/commands.js', // Đường dẫn tới tệp hỗ trợ
    //supportFile: 'cypress/support/HomePageAPI.js',
    fixturesFolder: 'cypress/fixtures', // Thư mục chứa các tệp fixtures
    screenshotsFolder: 'cypress/screenshots', // Thư mục chứa ảnh chụp màn hình
    videosFolder: 'cypress/videos', // Thư mục chứa video của các lần chạy test
    viewportWidth: 1000, // Chiều rộng khung nhìn của trình duyệt
    viewportHeight: 660, // Chiều cao khung nhìn của trình duyệt
    defaultCommandTimeout: 4000, // Thời gian chờ mặc định cho các lệnh
    pageLoadTimeout: 60000, // Thời gian chờ tải trang
    retries: {
      runMode: 2, // Số lần thử lại trong chế độ chạy thông thường
      openMode: 0, // Số lần thử lại trong chế độ mở
    },
    env: {
      // Biến môi trường tùy chỉnh
      //login_url: '/login', // URL đăng nhập
    },
    setupNodeEvents(on, config) {
      // Định nghĩa các sự kiện Node.js nếu cần thiết
    },
    //baseUrl: 'http://localhost:3000',
    //defaultCommandTimeout: 10000,
  },
  //defaultCommandTimeout: 5000
  //browser: 'chrome'
});
