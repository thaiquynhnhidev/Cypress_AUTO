export default class SignupComponent {
    getSignupModal = () => cy.get('.modal-dialog form')
    getUsername = () => cy.get('#sign-username')
    getPassword = () => cy.get('#sign-password')
    getSignupBtn = () => cy.get('[onclick="register()"]')

    //getLoginLink = () => cy.get('#login2')

}