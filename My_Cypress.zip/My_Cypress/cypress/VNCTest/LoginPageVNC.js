
describe('Login Page VNC Test', () => {

    it('Login successfully', () => {

        // Open the login form page
        //cy.wait(10000)
        cy.visit("/login")
        //cy.login('nhitq22', 'Nhi@12345');
        // Thêm các bước kiểm tra tiếp theo sau khi đăng nhập thành công
        //cy.get("input[type='text']").scrollIntoView(); 
        //cy.scrollTo(0, 500);
        //cy.wait(2000)

        //cy.url().should('include', '/login');
        //cy.contains('label', 'User name or email').should('be.visible')

        
        
        //cy.url().should('include', 'https://swap.vinachain.io/login')

        cy.get('#box .boxShadow').should('be.visible');

        // Find username by ID then input the text
        cy.get("#username").type("nhitq22", {force: true, waitForAnimations: true})
        //cy.get("input[type='text']").type("nhitq22")

        // Find password by ID then input the text
        cy.get("#password").type("Nhi@12345", {force: true, waitForAnimations: true})

        // Find login btn by attribute and tag name then click
        cy.get("button[type='button']").click({force: true})
        //cy.get('[class*="my-3"]').click()

        // DEBUG purpose only
        //cy.wait(10000)
    });

});
