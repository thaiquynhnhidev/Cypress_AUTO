/*
describe('Signup Page VNC Test', () => {

    it('Signup successfully', () => {

        // Open the login form page
        //cy.wait(10000)
        cy.visit("/register")
        //cy.login('nhitq22', 'Nhi@12345');
        // Thêm các bước kiểm tra tiếp theo sau khi đăng nhập thành công
        //cy.get("input[type='text']").scrollIntoView(); 
        //cy.scrollTo(0, 500);
        //cy.wait(2000)

        cy.url().should('include', '/register');
        //cy.url().should('include', 'https://swap.vinachain.io/login')

        //cy.get('#username').should('be.visible');

        // Find username by ID then input the text
        cy.get("#username").type("quynhnhithai")
        //cy.get("input[type='text']").type("nhitq22")

        cy.get("#email").type("quynhnhithai@yopmail.com")
        cy.get("#confirmEmail").type("quynhnhithai@yopmail.com")
        // Find password by ID then input the text
        cy.get("#password").type("Nhi@12345")
        cy.get("#confirmPassword").type("Nhi@12345")

        cy.get("#refCode").type("E839F60C14")

        cy.get("#agreement").click()
        cy.get("#checkbox_receive").click()

        // Find login btn by attribute and tag name then click
        cy.get("button[type='button']").click()
        //cy.get('[class*="my-3"]').click()

        // DEBUG purpose only
        cy.wait(10000)
    });

});
*/