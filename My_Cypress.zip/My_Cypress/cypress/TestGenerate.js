function generateRandomUser(usernameLength) {
    const ALL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const ALL_CHARS_LENGTH = ALL_CHARS.length;
    let randomUsername = '';
    for (let index = 0; index < ALL_CHARS_LENGTH; index++){
        randomUsername += ALL_CHARS.charAt(Math.floor(Math.random() * ALL_CHARS_LENGTH));
    }
    return randomUsername;
}

console.log(generateRandomUser(9))

// Run terminal: node [File].js