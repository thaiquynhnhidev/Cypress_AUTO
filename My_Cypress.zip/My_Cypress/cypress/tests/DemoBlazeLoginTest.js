import DemoBlazePage from "../models/pages/DemoBlazePage"
import { HomePageAPI } from "../support/HomePageAPI"

describe ('Demo Blaze Home page test', () => {

    let apiProduct
    beforeEach(() => {
        cy.login('tun', 'admin')
        //cy.visit('https://www.demoblaze.com')
        HomePageAPI.getHomePageProducts().then(entries => apiProduct = entries)
    })

    it('should be able login by using API', () => {
        cy.visit('https://www.demoblaze.com')
            let apiProductData = apiProduct.map(item => {
                return {
                    itemName: item.title.replace('\n', ''),
                    itemPrice: `$${item.price}`
                }
            })
            new DemoBlazePage().getAllCardData().then(allCardData => {
                cy.wrap('').then(() => {
                    //cy.log(JSON.stringify(allCardData))
                    expect(allCardData).to.be.deep.eq(apiProductData)
                })
            }) 
        })

})