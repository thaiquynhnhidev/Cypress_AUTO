import HeaderComponent from "../../models/components/HeaderComponent"
import LoginComponent from "../../models/components/LoginComponent"

const LOGIN_CREDS = {
    username: "tun",
    password: "admin"
}


describe('Login test', () => {
    let headerComp;
    let loginComp;
    beforeEach(() => {
        cy.visit('/')
        headerComp = new HeaderComponent()
        loginComp = new LoginComponent()
    })
    const login = (username, password) => {
        headerComp.getLoginLink().click();

        loginComp.getLoginModal().should('be.visible')
        loginComp.getUsername().type(`${username}`)
        loginComp.getPassword().type(`${password}`)
        loginComp.getLoginBtn().click()
    }

    it.only('should be able to login with correct creds', () => {

        const {username, password} = LOGIN_CREDS;
        login(username, password);

        //cy.get('#login2').click();
        //headerComp.getLoginLink().click();

        //loginComp.getLoginModal().should('be.visible')
        //loginComp.getUsername().type(`${LOGIN_CREDS.username}`)
        //loginComp.getPassword().type(`${LOGIN_CREDS.password}`)
        //loginComp.getLoginBtn().click()
        headerComp.getLoggedUsername().should('be.visible')
        headerComp.getLoggedUsername().should('contain.text', `Welcome ${LOGIN_CREDS.username}`)
        /*
        cy.get('#logInModal form').should('be.visible');

        cy.get('#loginusername').type(`${LOGIN_CREDS.username}`);
        cy.get('#loginpassword').type(`${LOGIN_CREDS.password}`);
        cy.get('[onclick="logIn()"]').click();
        
        cy.get('#nameofuser').should('be.visible');
        cy.get('#nameofuser').should('contain.text', `Welcome ${LOGIN_CREDS.username}`);
        */
    })


    it('should be able to see wrong password', () => {

        

        cy.get('#login2').click();

        cy.get('#logInModal form').should('be.visible');

        cy.get('#loginusername').type(`${LOGIN_CREDS.username}`);
        cy.get('#loginpassword').type(`${LOGIN_CREDS.password}_WRONG`);
        cy.get('[onclick="logIn()"]').click();

        cy.on('window:alert', alert => {
            //expect(alert).to.contains('User does not exist')
            expect(alert).to.contains('Wrong password')
            
        })

        /*
        cy.get('#nameofuser').should('be.visible');
        cy.get('#nameofuser').should('contain.text', `Welcome ${LOGIN_CREDS.username}`);
        */
    })
})