

const CHECKBOXES_SEL = "[type='checkbox']"
const DROPDOWN_SEL = "select[id='dropdown']"


describe('Element interaction', () => {

    it('should be able to complete the form', () => {
      /*
        // Open the dropdown form page
        cy.visit("/dropdown")
        // Select by index | Select option 1
        cy.get(DROPDOWN_SEL).select(1)
        // Select by value | Select option 2
        cy.get(DROPDOWN_SEL).select("2")
      
        // Select by visible text | Select option 1
        //cy.get(DROPDOWN_SEL).select("Option 1")
        // Verify the selected option is now option 1
        //cy.get("select option:selected").invoke("text").should("eq", "Option 1")
      */
      /*
        // Open the checkboxes form page
        cy.visit("/checkboxes")
        // Try to unselect the second checkbox
        cy.get(CHECKBOXES_SEL).eq(1).click()
        // Verify all checkboxes are unselected
        cy.get(CHECKBOXES_SEL).filter(":not([checked])").should("have.length", 2)
        // Loop over all checkboxes again then select all
        cy.get(CHECKBOXES_SEL).filter(":not([checked])").then(item => {
            cy.get(item).click({multiple:true})
        })
      */

        // Open the login form page
        //cy.visit("/login")
        // Find username by ID then input the text
        //cy.get("#username").type("tomsmith")

        // Find password by attribute name then input the text
        //cy.get("[name='password']").type("SuperSecretPassword!")

        // Find login btn by attribute and tag name then click
        //cy.get("button[type='submit']").click()

        //cy.login('tomsmith', 'SuperSecretPassword!')
        /*
        cy.visit("https://the-internet.herokuapp.com")
        cy.get("a[href='/login']").click()
        cy.location('pathname', {timeout: 500}).should("eq", "/login")
        */



        // DEBUG purpose only
        cy.wait(10000)
        
    })

})
/*
describe('My First Test', () => {
    it('clicking "type" navigates to a new url', () => {
      cy.visit('https://example.cypress.io')
  
      cy.contains('type').click()
  
      // Should be on a new URL which includes '/commands/actions'
      cy.url().should('include', '/commands/actions')
    })
  })
*/
/*
describe('My First Test', () => {
    it('clicking "type" shows the right headings', () => {
      cy.visit('https://example.cypress.io')
  
      //cy.pause()
  
      cy.contains('get').click()
  
      // Should be on a new URL which includes '/commands/actions'
      cy.url().should('include', '/commands/querying')
  
      // Get an input, type into it and verify that the value has been updated
      /*cy.get('.action-email')
        .type('fake@email.com')
        .should('have.value', 'fake@email.com')
      */
        //cy.get('#query-btn').should('contain', 'Button')
    /*
        cy.contains('Button').click()
      cy.pause()
    })
  })
*/