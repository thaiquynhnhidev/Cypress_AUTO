/*
[Scenario 01] | Order item as quest
* 1. Open the page
* 2. Select a random category
* 3. Select a random product
* 4. Add to cart
* 5. Go to card and verify cart details
* 6. Place order as quest


[Scenario 02] | Order item as logged in user
* 1. Login to the page
* 2. Place order as logged in user
* */


import ProductDetailsComponent from "../../models/components/ProductDetailsComponent"
import { HomePageAPI } from "../../support/HomePageAPI"
import HeaderComponent from "../../models/components/HeaderComponent"
import LoginComponent from "../../models/components/LoginComponent"


describe ('Product details test', () => {
    
    beforeEach(() => {
        cy.visit('/');
        
    })
    it ('Order item as guest', () => {
        purchaseItem()
    })

    it ('Order item as logged in user', () => {
        // Login
        const LOGIN_CREDS = {
            username: "tun",
            password: "admin"
        }
        const {username, password} = LOGIN_CREDS;
        login(username, password);
        // Purchase
        purchaseItem()
    })
})

const login = (username, password) => {

    let loginComp = new LoginComponent()
    let headerComp = new HeaderComponent()
    headerComp.getLoginLink().click();

    loginComp.getLoginModal().should('be.visible')
    loginComp.getUsername().type(`${username}`)
    loginComp.getPassword().type(`${password}`)
    loginComp.getLoginBtn().click()
}

const purchaseItem = () => {
    HomePageAPI.getHomePageProducts().then(apiData => { 
        const randomProduct = apiData[Math.floor(Math.random() * apiData.length)];
        const randomProductTitle = randomProduct.title;
        cy.contains(randomProductTitle).click();
        // Click on Add to cart button
        cy.contains('Add to cart').click()
        // Go to cart
        cy.get('#cartur').click()
        // Verify cart details

        // Place order
        cy.contains('Place Order').click()

        // Place order details
        cy.get('#name').type('tun')
        cy.get('#country').type('Vietnam')
        cy.get('#city').type('HCM')
        cy.get('#card').type('123456789')
        cy.get('#month').type('02')
        cy.get('#year').type('2023')
        cy.contains('Purchase').click()

        // Verification
        // Verify purchase confirm dialog
        
        cy.get('.sweet-alert h2').should('have.text', 'Thank you for your purchase!')
        cy.get('.sweet-alert .lead').then(($confirmOrderDetails) => {
            cy.wrap($confirmOrderDetails.should('contain.text', randomProduct.price))
            cy.wrap($confirmOrderDetails.should('contain.text', 'Card Number: 123456789'))
        })

        // DEBUG
        cy.wait(3000)
    })
}