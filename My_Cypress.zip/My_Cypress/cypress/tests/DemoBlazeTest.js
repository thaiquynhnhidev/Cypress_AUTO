import DemoBlazePage from "../models/pages/DemoBlazePage"
import products from "./products.json"
import {HomePageAPI} from "../support/HomePageAPI"

describe('Demo Blaze Page', () => {

    //const PRODUCT_DATA = []

    it('should be able to get all card data', () => {
        cy.visit('https://www.demoblaze.com/')
        new DemoBlazePage().getAllCardData().then(allCardData => {
            cy.wrap('').then(() => {
                //cy.log(JSON.stringify(allCardData))
                expect(allCardData).to.be.deep.eq(products)
            })
        })
    })

    it('should be able to get all card data', () => {
        cy.visit('https://www.demoblaze.com/')
        // Intercept default home page product
        cy.intercept('/entries').as('entries')
        cy.wait('@entries')
        cy.get('@entries').then(entries => {
            let apiProductData = entries.response.body.Items;
            apiProductData = apiProductData.map(item => {
                return {
                    itemName: item.title.replace('\n', ''),
                    itemPrice: `$${item.price}`
                }
            })
            new DemoBlazePage().getAllCardData().then(allCardData => {
                cy.wrap('').then(() => {
                    //cy.log(JSON.stringify(allCardData))
                    expect(allCardData).to.be.deep.eq(apiProductData)
                })
            })
        })
    })

    let apiProduct

    beforeEach(() => {
        cy.visit('https://www.demoblaze.com')
        HomePageAPI.getHomePageProducts().then(entries => apiProduct = entries)
        //cy.intercept('/entries').as('entries')
        //cy.wait('@entries')
        //cy.get('@entries').then(entries => apiProduct = entries)
    })

    it.only('should be able to get all card data with before hook', () => {
        let apiProductData = apiProduct.response.body.Items.map(item => {
            return {
                itemName: item.title.replace('\n', ''),
                itemPrice: `$${item.price}`
            }
        })
            new DemoBlazePage().getAllCardData().then(allCardData => {
                cy.wrap('').then(() => {
                    //cy.log(JSON.stringify(allCardData))
                    expect(allCardData).to.be.deep.eq(apiProductData)
                })
            })
        })
})