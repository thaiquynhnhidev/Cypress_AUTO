import ProductDetailsComponent from "../../models/components/ProductDetailsComponent"
import { HomePageAPI } from "../../support/HomePageAPI"


describe ('Product details test', () => {
    
    beforeEach(() => {
        cy.visit('/');
        
    })
    it ('should be able to verify product details', () => {

        HomePageAPI.getHomePageProducts().then(apiData => { 
            const randomProduct = apiData[Math.floor(Math.random() * apiData.length)];
            const randomProductTitle = randomProduct.title;
            cy.contains(randomProductTitle).click();

            const productDetails = new ProductDetailsComponent();
            productDetails.getProductImg().should('be.visible')
            productDetails.getProductName().should('have.text', randomProductTitle)
            productDetails.getProductPrice().should('contain.text', randomProduct.price)
            productDetails.getProductDesc().should('not.be.empty')

            // DEBUG
            cy.wait(3000)
        })
    })
})