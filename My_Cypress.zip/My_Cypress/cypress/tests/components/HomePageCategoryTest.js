import DemoBlazePage from "../../models/pages/DemoBlazePage"
import {HomePageAPI} from "../../support/HomePageAPI"

describe ('Home page category test', () => {

    beforeEach(() => {
        cy.visit('/')
        HomePageAPI._waitForEntriesRequest();
    })

    function verifyCategoryFilterBy(productName){
        cy.get(`[onclick="byCat(\'${productName}\')"]`).click({force: true});
        cy.intercept('/bycat').as('cats')
        cy.wait('@cats')
        cy.request({
            method: "POST",
            url: "https://api.demoblaze.com/bycat",
            body: {
                cat: `${productName}`
            }
        }).then(res => {
            let apiProductData = res.body.Items.map(item => {
                return {
                    itemName: item.title.replace('\n', ''),
                    itemPrice: `$${item.price}`
                }
            })
            //cy.log(JSON.stringify(apiProductData))
            new DemoBlazePage().getAllCardData().then(allCardData => {
                cy.wrap('').then(() => {
                    expect(allCardData).to.be.deep.eq(apiProductData)
                })
            })
        })
    }
    // Chạy lại 20 lần
    /*
    for(let i = 0; i < 20; i++)
    {
        it('', () => {
        })
    }
    */

    const SCENARIOS = ["phone", "notebook", "monitor"];
    SCENARIOS.forEach(product => {
        it('should be able to filter ${product} product', () => {
            verifyCategoryFilterBy(`${product}`);
        })
    })

    it ('should be able to filter phone products', () => {

        verifyCategoryFilterBy("phone");
    })

    it ('should be able to filter notebook products', () => {

        verifyCategoryFilterBy("notebook");
    })

    it ('should be able to filter monitor products', () => {

        cy.get('[onclick="byCat(\'monitor\')"]').click({force: true});
        cy.intercept('/bycat').as('cats')
        cy.wait('@cats')
        cy.request({
            method: "POST",
            url: "https://api.demoblaze.com/bycat",
            body: {
                cat: "monitor"
            }
        }).then(res => {
            let apiProductData = res.body.Items.map(item => {
                return {
                    itemName: item.title.replace('\n', ''),
                    itemPrice: `$${item.price}`
                }
            })
            //cy.log(JSON.stringify(apiProductData))
            new DemoBlazePage().getAllCardData().then(allCardData => {
                cy.wrap('').then(() => {
                    expect(allCardData).to.be.deep.eq(apiProductData)
                })
            })
        })
    })
    
})