import HeaderComponent from "../../models/components/HeaderComponent"

describe ('Header component test', () => {

    const BRAND_TEXT = 'PRODUCT STORE'
    let headerComp;
    /*
    beforeEach(() => {
        cy.visit('/')
    })
    */
    before(() => {
        cy.visit('/')
        headerComp = new HeaderComponent()
    })

    it ('Test for brand logo', () => {
        
        headerComp.brandLogoImg().should('be.visible')
        headerComp.brandLogo().should('contain.text', BRAND_TEXT)
    })

    it ('Test for header menu details', () => {

        const expectedMenuDetails = []

        headerComp.getMenuDetails().then(menuDetailsData => {
            cy.log(JSON.stringify(menuDetailsData))
        })
        /*
        const headerComp = new HeaderComponent()
        headerComp.headerMenuItemList().each(menuItem => {
            cy.wrap(menuItem).should('not.be.empty')
        })
        */
    })
})