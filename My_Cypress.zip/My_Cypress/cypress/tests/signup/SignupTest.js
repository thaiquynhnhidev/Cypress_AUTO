import HeaderComponent from "../../models/components/HeaderComponent"
import SignupComponent from "../../models/components/SignupComponent"

const generateRandomUser = usernameLength => {
    const ALL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const ALL_CHARS_LENGTH = ALL_CHARS.length;
    let randomUsername = '';
    for (let index = 0; index < ALL_CHARS_LENGTH; index++){
        randomUsername += ALL_CHARS.charAt(Math.floor(Math.random() * ALL_CHARS_LENGTH));
    }
    return randomUsername;
}

const SIGNUP_CREDS = {
    username: generateRandomUser(9),
    password: "admin"
}


describe('Signup test', () => {
    let headerComp;
    let signupComp;
    beforeEach(() => {
        cy.visit('/')
        headerComp = new HeaderComponent()
        signupComp = new SignupComponent()
    })
    const signup = (username, password) => {
        headerComp.getSignupLink().click();

        signupComp.getSignupModal().should('be.visible')
        signupComp.getUsername().type(`${username}`)
        signupComp.getPassword().type(`${password}`)
        signupComp.getSignupBtn().click()
    }

    it('should be able to create a new user', () => {

        const {username, password} = SIGNUP_CREDS;
        signup(username, password);

        cy.on('window:alert', alert => {
            expect(alert).to.contains('Sign up successful')
            
        })

        //cy.get('#login2').click();
        //headerComp.getLoginLink().click();

        //loginComp.getLoginModal().should('be.visible')
        //loginComp.getUsername().type(`${LOGIN_CREDS.username}`)
        //loginComp.getPassword().type(`${LOGIN_CREDS.password}`)
        //loginComp.getLoginBtn().click()
        //headerComp.getLoggedUsername().should('be.visible')
        //headerComp.getLoggedUsername().should('contain.text', `Welcome ${SIGNUP_CREDS.username}`)
        /*
        cy.get('#logInModal form').should('be.visible');

        cy.get('#loginusername').type(`${LOGIN_CREDS.username}`);
        cy.get('#loginpassword').type(`${LOGIN_CREDS.password}`);
        cy.get('[onclick="logIn()"]').click();
        
        cy.get('#nameofuser').should('be.visible');
        cy.get('#nameofuser').should('contain.text', `Welcome ${LOGIN_CREDS.username}`);
        */
    })


    it('should be able to see existing username', () => {

        const {password} = SIGNUP_CREDS;
        signup("tun", password);
        cy.on('window:alert', alert => {
            expect(alert).to.contains('This user already exist')
            //expect(alert).to.contains('Wrong password')
            
        })
        /*
        cy.get('#signin2').click();

        cy.get('#logInModal form').should('be.visible');

        cy.get('#loginusername').type(`${LOGIN_CREDS.username}`);
        cy.get('#loginpassword').type(`${LOGIN_CREDS.password}_WRONG`);
        cy.get('[onclick="logIn()"]').click();

        /*
        cy.get('#nameofuser').should('be.visible');
        cy.get('#nameofuser').should('contain.text', `Welcome ${LOGIN_CREDS.username}`);
        */

        //after(() => {
            // Delete registered accounts 
        //})
    })
})