// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
/*
Cypress.Commands.add('login', (username, password) => {
    cy.visit('https://swap.vinachain.io/login');
    cy.get('#username').type(username);
    cy.get('#password').type(password);
    cy.get('button[type=button]').click();
  });
  */
/*
Cypress.Commands.add('login', (username, password) => {
    cy.visit('/login');
    cy.get('#username').type(username);
    cy.get('#password').type(password);
    cy.get('button[type="submit"]').click();
})
*/
/**
 * @memberOf cy
 * @method login
 */


Cypress.Commands.add('login', (username, password) => {
  cy.request({
    method: 'POST',
    url: 'https://api.demoblaze.com/login', // Địa chỉ API đăng nhập
    body: {
      username,
      password
    }
  }).then((response) => {
    expect(response.status).to.eq(200); // Kiểm tra xem yêu cầu có thành công không
    
    // Log toàn bộ phản hồi để kiểm tra cấu trúc
    cy.log(JSON.stringify(response.body));

    //const token = response.body.token; // Lấy token từ phản hồi
    const token = response.body.data.token; 

    cy.setCookie('auth_token', token);
    // Kiểm tra token có phải là chuỗi không
    /*
    if (typeof token === 'string') {
      cy.setCookie('auth_token', token); // Lưu token trong cookie để sử dụng trong các yêu cầu tiếp theo
    } else {
      throw new Error('Token is not a string');
    }
  });
  /*
  /*
    cy.request({
      url: 'https://api.demoblaze.com/login',
      method: 'POST',
      headers: {
          contentType: "application/json"
      },
      body: {
          username: username, password: btoa(password)
      }
  }).then((response) => {
    expect(response.status).to.eq(200); // Kiểm tra xem yêu cầu có thành công không
    
    // Log toàn bộ phản hồi để kiểm tra cấu trúc
    cy.log(JSON.stringify(response.body));

    const token = response.body.token; // Lấy token từ phản hồi

    // Kiểm tra token có phải là chuỗi không
    cy.setCookie('auth_token', token)
    /*
      const {authToken} = res.body.split('Auth_token: ')[1];
      cy.log(authToken)
      //cy.setCookie('auth_token', authToken)
      // Kiểm tra token có phải là chuỗi không
    if (typeof token === 'string') {
      cy.setCookie('auth_token', token); // Lưu token trong cookie để sử dụng trong các yêu cầu tiếp theo
    } else {
      throw new Error('Token is not a string');
    }
    */
  }) 
})


